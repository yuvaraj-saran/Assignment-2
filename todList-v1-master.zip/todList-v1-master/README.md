simple todo list app using NodeJS, Express, EJS, npm module body-parser and implementing JS custom modules concept; the app have three pages main route, work and about.
the app is live here : https://gentle-sands-84170.herokuapp.com/
